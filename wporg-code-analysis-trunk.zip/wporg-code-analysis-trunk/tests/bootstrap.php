<?php

require( dirname( __DIR__ ) . '/vendor/autoload.php' );
require_once( dirname( __DIR__ ) . '/vendor/squizlabs/php_codesniffer/tests/bootstrap.php' );
